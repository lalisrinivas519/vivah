<div id="preloader">
   <div class="plod">
      <span class="lod1"><img src="images/loder/1.png" alt="" loading="lazy"></span>
      <span class="lod2"><img src="images/loder/2.png" alt="" loading="lazy"></span>
      <span class="lod3"><img src="images/loder/3.png" alt="" loading="lazy"></span>
   </div>
</div>
