<section class="wed-hom-footer">
   <div class="container">
      <div class="row foot-supp">
         <h2><span>Free support:</span> +92 (8800) 68 - 8960 &nbsp;&nbsp;|&nbsp;&nbsp; <span>Email:</span>
            info@example.com
         </h2>
      </div>
      <div class="row wed-foot-link wed-foot-link-1">
         <div class="col-md-4">
            <h4>Get In Touch</h4>
            <p>Address: Bengalaru</p>
            <p>Phone: <a href="tel:+917904462944">+92 (8800) 68 - 8960</a></p>
            <p>Email: <a href="mailto:info@example.com">info@example.com</a></p>
         </div>
         <div class="col-md-4">
            <h4>HELP &amp; SUPPORT</h4>
            <ul>
               <li><a href="index.php">Home</a>
               </li>
               <li><a href="about.php">About Us</a>
               </li>
               <li><a href="plan.php">Plans</a>
               </li>
               <li><a href="service.php">Services</a>
               </li>
               <li><a href="register.php">Register</a>
               </li>
               <li><a href="login.php">Login</a>
               </li>
            </ul>
         </div>
         <div class="col-md-4 fot-soc">
            <h4>Subscribe</h4>
            <ul>
               <form class="ca-two-newsletter-form mt-40 position-relative">
                  <input type="text" class="form-control" placeholder="Enter your email" name="email" required="" autocomplete="off">
                  <br><button type="button" class="btn btn-outline-secondary"><a href="#" >Submit</a></button></p>
               </form>
            </ul>
         </div>
      </div>
      <div class="row foot-count">
         <p>Shubhavivaha - Trusted by over thousands of Boys & Girls for successfull marriage. <a
            href="login.php" class="btn btn-primary btn-sm">Join us today !</a></p>
      </div>
   </div>
</section>
<!-- END -->
<!-- COPYRIGHTS -->
<section>
   <div class="cr">
      <div class="container">
         <div class="row">
            <p>Copyright © <span id="cry">2024</span> <a href="#!" target="_blank">Shubhavivaha</a></p>
         </div>
      </div>
   </div>
</section>