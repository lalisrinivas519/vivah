<?php

 $con=mysqli_connect("localhost", "root", "", "vivaha");

if (mysqli_connect_error()) {
	echo "Connection Error.";
} 
?>
